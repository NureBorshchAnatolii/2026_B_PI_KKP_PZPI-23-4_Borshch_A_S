namespace Menterview.Application.Dtos.Sub;

public class RoleDto
{
    public int RoleId { get; set; }
    public string RoleName { get; set; } = null!;
}
